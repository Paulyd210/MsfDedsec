#/usr/bin/bash
echo -e "\033[33m Installing Requirements......"
read -t 1
sudo apt install wifite aircrack-ng crunch
