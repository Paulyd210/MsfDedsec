#/usr/bin/bash
cd veil
apt install python python-dev python2.7 python-all-dev
python Veil-Evasion.py
